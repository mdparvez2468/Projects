package com.example.demotask.views

import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.util.Base64
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.demotask.R
import com.example.demotask.databinding.FragmentCountryBinding
import com.example.demotask.models.Country
import com.example.demotask.models.CountryRemoteKeys
import com.example.demotask.models.CountrySample
import com.example.demotask.viewmodels.CountryViewModelWithoutFactory
import kotlin.collections.ArrayList


class CountryFragment : Fragment() {


    lateinit var binding: FragmentCountryBinding

    //lateinit var countryViewModel: CountryViewModel
    lateinit var  countryViewModelWithoutFactory: CountryViewModelWithoutFactory


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val args = CountryFragmentArgs.fromBundle(requireArguments())


        binding = FragmentCountryBinding.inflate(inflater)

        //val repository = (requireContext().applicationContext as CountryApplication).countryRepository

        countryViewModelWithoutFactory = ViewModelProvider(requireActivity()).get(CountryViewModelWithoutFactory::class.java)

        val filteredList = ArrayList<CountryRemoteKeys>()

        countryViewModelWithoutFactory.countries?.observe(requireActivity(), Observer {
            for (item in it) {

                //item.code.contains(args.code)
                if (args.code.contains(item.name)) {

                    filteredList.add(item)
                }
            }
            if (filteredList.isNotEmpty()) {

                //Toast.makeText(requireContext(),"Code: "+args.code,Toast.LENGTH_SHORT).show()

                val imageBytes = Base64.decode(filteredList.get(0).flag, Base64.DEFAULT)
                val decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                binding.countryFragmentIV.setImageBitmap(decodedImage)





                if(filteredList.get(0).voiceSmsSubscriptionPrice.toString() != "0.0"){

                    binding.countrySample = CountrySample(filteredList.get(0).name,filteredList.get(0).flag,filteredList.get(0).voiceSmsSubscriptionPrice.toString())

                }else{

                    binding.countrySample = CountrySample(filteredList.get(0).name,filteredList.get(0).flag,filteredList.get(0).voiceSubscriptionPrice.toString())

                }



                if (filteredList.get(0).voice){
                    binding.countryFragmentVoiceTV.setBackgroundResource(R.drawable.voice_select_bg)
                    binding.countryFragmentVoiceTV.setTextColor(Color.parseColor("#FFFFFF"))
                }else{
                    binding.countryFragmentVoiceTV.setBackgroundResource(R.drawable.voice_bg)
                    binding.countryFragmentVoiceTV.setTextColor(Color.parseColor("#000000"))
                }

                if (filteredList.get(0).sms){
                    binding.countryFragmentSmsTV.setBackgroundResource(R.drawable.voice_select_bg)
                    binding.countryFragmentSmsTV.setTextColor(Color.parseColor("#FFFFFF"))
                }else{
                    binding.countryFragmentSmsTV.setBackgroundResource(R.drawable.voice_bg)
                    binding.countryFragmentSmsTV.setTextColor(Color.parseColor("#000000"))
                }

                binding.countryFragmentRateTV.text = "Rate: ${filteredList.get(0).voiceSmsSubscriptionPrice}"

            if (filteredList.get(0).city.isNotEmpty()){

                val cityList = ArrayList<String>()
                for (i in filteredList.get(0).city) {

                    cityList.add(i.name)

                }


                val arrayAdapter = ArrayAdapter<String>(requireContext(),android.R.layout.simple_list_item_1,cityList)

                binding.mainListView.adapter = arrayAdapter


            }




            }
        })





        return binding.root
    }


}