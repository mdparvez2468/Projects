package com.example.demotask.views

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import com.example.demotask.apis.CountryService
import com.example.demotask.apis.RetrofitHelper
import com.example.demotask.repository.CountryRepository
import com.example.demotask.db.CountryDatabase
import com.example.demotask.utils.NetworkReceiver

class CountryApplication: Application() {


    override fun onCreate() {
        super.onCreate()

        val postService = RetrofitHelper.getInstance().create(CountryService::class.java)

        val database = CountryDatabase.getDatabase(applicationContext)
        repository = CountryRepository(postService, database,applicationContext)

        receiver = NetworkReceiver(applicationContext)

    }

    companion object {
        var repository: CountryRepository? = null
        @SuppressLint("StaticFieldLeak")
        var receiver: NetworkReceiver? = null

        fun getRepo(): CountryRepository?{
            return repository
        }

        fun getNetworkState(): NetworkReceiver?{
            return receiver
        }

    }
}