package com.example.demotask

import android.graphics.BitmapFactory
import android.util.Base64
import android.widget.ImageView
import androidx.databinding.BindingAdapter

@BindingAdapter("imageRedFromBase64")
fun ImageView.imageRedFromBase64(value: String){
    val imageBytes = Base64.decode(value, Base64.DEFAULT)
    val decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
    this.setImageBitmap(decodedImage)
}