package com.example.demotask.repository

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.liveData
import com.example.demotask.apis.CountryService
import com.example.demotask.models.Country
import com.example.demotask.utils.NetworkCheck
import com.example.demotask.db.CountryDatabase
import com.example.demotask.models.CountryRemoteKeys
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class CountryRepository(
    private val countryService: CountryService,
    private val countryDatabase: CountryDatabase,
    private val applicationContext: Context
) {

    private val countryLiveData = MutableLiveData<List<CountryRemoteKeys>>()
    val countries: LiveData<List<CountryRemoteKeys>> get() = countryLiveData






     @JvmName("getCountries1")
     fun getCountries() = Pager(
        config = PagingConfig(pageSize = 20, maxSize = 100),
        pagingSourceFactory = { CountryPagingSource(countryDatabase) }
    ).liveData
    suspend fun loadData(){


            if (NetworkCheck.isInternetAvailable(applicationContext)){
                val result = countryService.getCountries()

                if (result.body() != null){


                    val list: MutableList<CountryRemoteKeys> = mutableListOf()

                    var count = 0
                    var key = 1
                    for (post in result.body()!!){

                        count++
                        if (count==10){
                            key++
                            count=0
                        }
                        list.add(CountryRemoteKeys(
                            0,
                            post.name,
                            post.code,
                            post.ISO,
                            post.flag,
                            post.voiceSmsSubscriptionPrice,
                            post.voiceSubscriptionPrice,
                            post.city,
                            post.province,
                            post.state,
                            post.voiceSms,
                            post.voice,
                            post.sms,
                            key)
                        )



                    }



                    countryDatabase.postDao()?.deletePost()
                    countryDatabase.postDao()?.insert(list)
                }
            }



    }
}