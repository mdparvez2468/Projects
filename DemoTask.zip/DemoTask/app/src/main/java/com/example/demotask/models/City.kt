package com.example.demotask.models

data class City(
    val id: String,
    val name: String
)
