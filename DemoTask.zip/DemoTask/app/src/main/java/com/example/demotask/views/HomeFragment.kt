package com.example.demotask.views

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.get
import androidx.paging.PagingData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.demotask.databinding.FragmentHomeBinding
import com.example.demotask.models.Country
import com.example.demotask.models.CountryRemoteKeys
import com.example.demotask.utils.NetworkReceiver
import com.example.demotask.viewmodels.CountryViewModelWithoutFactory
import java.util.*
import kotlin.collections.ArrayList


class HomeFragment : Fragment() {

    private lateinit var receiver: NetworkReceiver

    lateinit var binding: FragmentHomeBinding
    lateinit var countryAdapter: CountryAdapter

    lateinit var  countryViewModelWithoutFactory: CountryViewModelWithoutFactory



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        binding = FragmentHomeBinding.inflate(inflater)

        countryAdapter = CountryAdapter()
        binding.mainRV.adapter = countryAdapter
        binding.mainRV.layoutManager = LinearLayoutManager(requireContext())

        countryViewModelWithoutFactory = ViewModelProvider(requireActivity()).get(CountryViewModelWithoutFactory::class.java)

        countryViewModelWithoutFactory.progressButton.observe(requireActivity(), Observer {
            if (it){
                binding.mainPB.visibility = View.VISIBLE
            }else{
                binding.mainPB.visibility = View.GONE
            }
        })

       /* countryViewModelWithoutFactory.countries?.observe(requireActivity(), Observer {
            countryAdapter.setListData(it)
            countryAdapter.notifyDataSetChanged()
        })*/

        countryViewModelWithoutFactory.list?.observe(requireActivity(), Observer {
            countryAdapter.submitData(lifecycle,it)
        })

        voiceBtbCheck()
        smsBTNCheck()


        receiver = CountryApplication.getNetworkState()!!
        receiver.observe(requireActivity(), Observer {

            if (it){

                binding.networkToast.setBackgroundColor(Color.parseColor("#5105C10C"))
                binding.networkToastTV.text = "Back Online"
                binding.networkToastIB.visibility = View.VISIBLE


            }else{


                binding.networkToast.visibility = View.VISIBLE
                binding.networkToastIB.visibility = View.INVISIBLE
                binding.networkToast.setBackgroundColor(Color.parseColor("#45FF2222"))
                binding.networkToastTV.text = "No Internet Connection"
            }
        })

        binding.honeSearchET.addTextChangedListener { res ->
            try {
                filter(res.toString())
            }catch (e:Throwable){

            }
        }

        binding.homeVoiceBTN.setOnClickListener {

            countryViewModelWithoutFactory.voiceBtnStatusChange()

            voiceBtbCheck()

            filter(binding.honeSearchET.text.toString())

        }
        binding.homeSMSBTN.setOnClickListener {

            countryViewModelWithoutFactory.smsBtnStatusChange()

            smsBTNCheck()

            filter(binding.honeSearchET.text.toString())


        }
        binding.networkToastIB.setOnClickListener {

            countryViewModelWithoutFactory.reloadData()
            binding.networkToast.visibility = View.GONE


        }

        binding.swipeRefreshLayout.setOnRefreshListener {
            countryViewModelWithoutFactory.reloadData()
            binding.swipeRefreshLayout.isRefreshing = false
        }

        return binding.root
    }



    private fun voiceBtbCheck() {
        countryViewModelWithoutFactory.voiceButton.observe(requireActivity(), Observer {
            if (it){
                binding.homeVoiceBTN.setBackgroundColor(0xff000050.toInt())
                binding.homeVoiceBTN.setTextColor(Color.parseColor("#FF0000"))
            }else{
                binding.homeVoiceBTN.setBackgroundColor(0xff60a0e0.toInt())
                binding.homeVoiceBTN.setTextColor(Color.parseColor("#000000"))

            }
        })
    }

    private fun smsBTNCheck() {
        countryViewModelWithoutFactory.smsButton.observe(requireActivity(), Observer {
            if (it){
                binding.homeSMSBTN.setBackgroundColor(0xff000050.toInt())
                binding.homeSMSBTN.setTextColor(Color.parseColor("#FF0000"))
            }else{
                binding.homeSMSBTN.setBackgroundColor(0xff60a0e0.toInt())
                binding.homeSMSBTN.setTextColor(Color.parseColor("#000000"))
            }
        })
    }

    /**
     *
     *
     * @param text
     * @return
     **/
    private fun filter(text: String) {
        val filteredList = ArrayList<CountryRemoteKeys>()

        countryViewModelWithoutFactory.countries?.observe(requireActivity(), Observer {
            for (item in it) {
                if (countryViewModelWithoutFactory.smsButton.value!! && countryViewModelWithoutFactory.voiceButton.value!!){
                    if ((item.name.lowercase().contains(text.lowercase(Locale.getDefault())) || item.ISO.lowercase().contains(text.lowercase(Locale.getDefault()))) && item.voiceSms) {
                        filteredList.add(item)
                    }
                }else if (countryViewModelWithoutFactory.voiceButton.value!!){

                    if ((item.name.lowercase().contains(text.lowercase(Locale.getDefault())) || item.ISO.lowercase().contains(text.lowercase(Locale.getDefault()))) && item.voice) {
                        filteredList.add(item)
                    }

                }else if (countryViewModelWithoutFactory.smsButton.value!!){

                    if ((item.name.lowercase().contains(text.lowercase(Locale.getDefault())) || item.ISO.lowercase().contains(text.lowercase(Locale.getDefault()))) && item.sms) {
                        filteredList.add(item)
                    }

                }else{

                    if (item.name.lowercase().contains(text.lowercase(Locale.getDefault())) || item.ISO.lowercase().contains(text.lowercase(Locale.getDefault()))) {
                        filteredList.add(item)
                    }
                }

            }
            if (filteredList.isNotEmpty()) {
                countryAdapter.filter(filteredList)
            }else{
                countryAdapter.filter(emptyList())
            }
        })
    }
}