package com.example.demotask.db

import androidx.room.TypeConverter
import com.example.demotask.models.City
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Convertors {


    @TypeConverter
    fun fromListToString(value: List<City>): String{
        return Gson().toJson(value)
    }

    @TypeConverter
    fun fromStringToList(value:String): List<City> {

        val type = object : TypeToken<List<City>>(){}.type
        return Gson().fromJson(value, type)
    }

    @TypeConverter
    fun fromLMapToString(value:  Map<String, List<City>>): String{
        return Gson().toJson(value)
    }

    @TypeConverter
    fun fromStringToMap(value:String):  Map<String, List<City>> {

        val type = object : TypeToken< Map<String, List<City>>>(){}.type
        return Gson().fromJson(value, type)
    }


}