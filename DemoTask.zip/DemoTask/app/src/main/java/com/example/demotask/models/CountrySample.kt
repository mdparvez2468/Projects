package com.example.demotask.models

data class CountrySample(
    val name: String,
    val image: String,
    val voiceSmsSubscriptionPrice: String
)
