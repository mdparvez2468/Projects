package com.example.demotask.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.demotask.models.Country
import com.example.demotask.models.CountryRemoteKeys

@Database(entities = [CountryRemoteKeys::class], version = 1)
@TypeConverters(Convertors::class)
abstract class CountryDatabase: RoomDatabase() {
    abstract fun postDao(): CountryDao

    companion object{
        @Volatile
        private var INSTANCE: CountryDatabase? = null

        fun getDatabase(context: Context): CountryDatabase {
            if (INSTANCE == null){
                synchronized(this){
                    INSTANCE = Room.databaseBuilder(context, CountryDatabase::class.java,"CountryDB").build()
                }
            }
            return INSTANCE!!
        }
    }
}