package com.example.demotask.views

import android.annotation.SuppressLint
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil

import androidx.recyclerview.widget.RecyclerView
import com.example.demotask.views.CountryAdapter.*
import com.example.demotask.databinding.CountrySampleBinding
import com.example.demotask.models.Country
import com.example.demotask.models.CountryRemoteKeys
import com.example.demotask.models.CountrySample

class CountryAdapter : PagingDataAdapter<CountryRemoteKeys,CountryAdapter.CountryViewHolder>(ARTICLE_DIFF_CALLBACK) {



    class CountryViewHolder(private val binding: CountrySampleBinding) : RecyclerView.ViewHolder(binding.root) {


        fun bin(countrySample: CountrySample){
            binding.countrySample = countrySample
        }



    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val binding = CountrySampleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CountryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {

        val countrySample: CountrySample

        if(getItem(position)?.voiceSmsSubscriptionPrice.toString() != "0.0"){

            countrySample = CountrySample(getItem(position)?.name!!, getItem(position)?.flag!!, getItem(position)?.voiceSmsSubscriptionPrice.toString())

        }else{

            countrySample = CountrySample(getItem(position)?.name!!, getItem(position)?.flag!!, getItem(position)?.voiceSubscriptionPrice.toString())

        }



        holder.bin(countrySample)

        if (position%2==0){
            holder.itemView.setBackgroundColor(Color.parseColor("#CCCCCC"))
        }else{
            holder.itemView.setBackgroundColor(Color.parseColor("#EEEEEE"))
        }

        holder.itemView.setOnClickListener {

            holder.itemView.findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToCountryFragment(getItem(position)?.name!!))



        }
    }




    @SuppressLint("NotifyDataSetChanged")
    fun filter(filterList: List<CountryRemoteKeys>){
        //this.countries = filterList
        Log.i("TAG", "filter: $filterList")
        notifyDataSetChanged()
    }



    companion object {
        private val ARTICLE_DIFF_CALLBACK = object : DiffUtil.ItemCallback<CountryRemoteKeys>() {
            override fun areItemsTheSame(oldItem: CountryRemoteKeys, newItem: CountryRemoteKeys): Boolean =
                oldItem.countryID == newItem.countryID

            override fun areContentsTheSame(oldItem: CountryRemoteKeys, newItem: CountryRemoteKeys): Boolean =
                oldItem == newItem
        }
    }

}