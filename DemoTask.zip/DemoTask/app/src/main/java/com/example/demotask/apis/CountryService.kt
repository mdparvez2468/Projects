package com.example.demotask.apis

import com.example.demotask.models.Country
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers

interface CountryService {

    @Headers("x-access-token: phoring-header-token")
    @GET("phoring-json")
    suspend fun getCountries(): Response<List<Country>>

}