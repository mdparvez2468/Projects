package com.example.demotask.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.cachedIn
import com.example.demotask.models.Country
import com.example.demotask.models.CountryRemoteKeys
import com.example.demotask.views.CountryApplication
import com.example.demotask.views.MainActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CountryViewModelWithoutFactory : ViewModel() {


    private val  _voiceButton = MutableLiveData<Boolean>()
    val voiceButton: LiveData<Boolean> get() = _voiceButton

    private val  _smsButton = MutableLiveData<Boolean>()
    val smsButton: LiveData<Boolean> get() = _smsButton

    private val  _progressButton = MutableLiveData<Boolean>()
    val progressButton: LiveData<Boolean> get() = _progressButton


    private val repository = CountryApplication.getRepo()

    init {

        _voiceButton.value = false
        _smsButton.value = false

        reloadData()
    }


    val countries: LiveData<List<CountryRemoteKeys>>?
        get() = repository?.countries



    fun voiceBtnStatusChange(){
        _voiceButton.value = _voiceButton.value != true
    }
    fun smsBtnStatusChange(){
        _smsButton.value = _smsButton.value != true
    }

    var list = CountryApplication.getRepo()?.getCountries()?.cachedIn(viewModelScope)

    fun reloadData(){

        viewModelScope.launch(Dispatchers.IO) {
            _progressButton.postValue(true)
            repository?.getCountries()

            _progressButton.postValue(false)
        }
        viewModelScope.launch {
           // repository?.loadData()
        }

    }















}