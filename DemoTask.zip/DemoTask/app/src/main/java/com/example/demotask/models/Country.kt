package com.example.demotask.models

import com.google.gson.annotations.SerializedName

data class Country(
    val name: String,
    val code: String,
    val ISO: String,
    val flag: String,
    @SerializedName("voice_sms_subscription_price")
    val voiceSmsSubscriptionPrice: Float,
    @SerializedName("voice_subscription_price")
    val voiceSubscriptionPrice: Float,
    val city: List<City>,
    var province : Map<String, List<City>>,
    var state : Map<String, List<City>>,
    @SerializedName("voice_sms")
    val voiceSms: Boolean,
    val voice: Boolean,
    val sms: Boolean
)
