package com.example.demotask.repository

import android.util.Log
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.demotask.db.CountryDatabase
import com.example.demotask.models.CountryRemoteKeys
import kotlinx.coroutines.delay

private const val STARTING_KEY = 1

class CountryPagingSource(private val database: CountryDatabase): PagingSource<Int, CountryRemoteKeys>() {
    override fun getRefreshKey(state: PagingState<Int, CountryRemoteKeys>): Int? {
        return state.anchorPosition?.let {
            state.closestPageToPosition(it)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(it)?.nextKey?.minus(1)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, CountryRemoteKeys> {
        return try {

            val startKey = params.key ?: STARTING_KEY

            val source = database.postDao().get(startKey)

            if (startKey != STARTING_KEY) delay(3_000L)

            LoadResult.Page(
                data = source,
                prevKey = if (startKey==0) null else startKey-1,
                nextKey = if (startKey==source?.size) null else startKey+1
            )

        }catch (e: Exception){
            LoadResult.Error(e)
        }
    }
}