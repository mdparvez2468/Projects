package com.example.demotask.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.demotask.models.Country
import com.example.demotask.models.CountryRemoteKeys

@Dao
interface CountryDao {
    @Insert
    suspend fun insert(posts: List<CountryRemoteKeys>)

    @Query("SELECT * FROM country WHERE `key` = :keys")
    suspend fun get(keys: Int): List<CountryRemoteKeys>

    @Query("DELETE FROM country")
    suspend fun deletePost()

}